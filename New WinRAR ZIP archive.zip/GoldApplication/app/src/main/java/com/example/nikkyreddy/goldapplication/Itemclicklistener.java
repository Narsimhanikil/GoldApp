package com.example.nikkyreddy.goldapplication;

import android.view.View;

public interface Itemclicklistener {
    void onClick(View view, int position, boolean islongcLick);
}
