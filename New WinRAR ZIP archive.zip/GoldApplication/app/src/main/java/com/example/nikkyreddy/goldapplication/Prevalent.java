package com.example.nikkyreddy.goldapplication;

public class Prevalent {
    public static User currentonLineUser;
    public static final String UserPhoneKey="UserPhone";
    public static final String UserPasswordKey="UserPassword";
}
